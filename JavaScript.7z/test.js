/*
let Person={
    name: 'matt',
    age:27
};

let{name:personname,age}=Person;
console.log(personname)

console.log(undefined == null);
console.log(NaN == NaN);*/
let arr = [];
$.ajax({
type:'GET',
url:"./params.json",
dataType:"json",
async:false,
success:function(data){
    for (let Key1 in data) {
        let de = data[Key1];
        for(let Key2 in de) {
          if((de[Key2].id!=undefined && de[Key2].id<8000)||(de[Key2]["Attributes"]!=undefined && de[Key2]["Attributes"].id!=undefined && de[Key2]["Attributes"].id<8000)){
             if(de[Key2]["Attributes"]!=undefined){
                 arr.push({
                 name: "flaw_type_"+de[Key2]["Attributes"].id,
                 nickName:`${de["Attributes"].show}`+`_${de[Key2]["Attributes"].show}`
             });
          }else{
                 arr.push({
                     name: "flaw_type_"+de[Key2].id,
                     nickName:`${de[Key2].show}`
                 });
            }
          }
        }
    }
}
});
console.log(arr);

